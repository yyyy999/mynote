# TileLang PyTorch Adapter Demo

这是一个将 TileLang 算子集成到 PyTorch 的示例项目，采用 Python C Binding 方式实现。

## 目录结构

```
torch_tl_demo/
├── compile_tl_op/           # 编译工具：将 TileLang 算子编译为 .so
│   ├── __init__.py
│   ├── elementwise_add.py   # 元素级加法算子的编译脚本
│   └── util.py              # 工具函数
├── elementwise_add/         # 算子源码（独立于 PyTorch）
│   ├── __init__.py
│   └── elem_add.py          # TileLang 算子定义
├── src/
│   ├── _inner.cpp           # Python C 模块 + PyTorch 算子注册
│   └── torch_tl_demo/       # Python 包
│       ├── __init__.py
│       ├── VERSION
│       ├── libop.so         # 编译后的算子库（安装时生成）
│       └── op_source/       # 打包的算子源码
│           └── elementwise_add/
│               └── elem_add.py
├── setup.py                 # 安装脚本
├── test_torch.py            # 测试 PyTorch 算子
└── test_source.py           # 测试打包的源码
```

## 核心设计

### 1. 算子定义层（与 PyTorch 解耦）

```python
# elementwise_add/elem_add.py
import tilelang
import tilelang.language as T

@tilelang.jit(out_idx=[2], target="cuda")
def elementwise_add(M, N, block_M=32, block_N=32):
    @T.prim_func
    def main(A, B, C):
        # ... kernel implementation
    return main
```

### 2. 编译层（将算子编译为 .so）

```python
# compile_tl_op/elementwise_add.py
def update_package_files():
    op_func = get_jit_op_func()  # 获取 @tilelang.jit 装饰的函数
    
    # 复制源码到包目录
    shutil.copy(source_path, package_source_path)
    
    # 编译并复制 .so
    kernel = op_func(M, N)
    shutil.copy(so_path, package_so_path)
```

### 3. C++ 适配层（注册 PyTorch 算子）

```cpp
// src/_inner.cpp
extern "C" {
    void call(float* A, float* B, float* C, int64_t M, int64_t N, cudaStream_t stream);
}

at::Tensor elementwise_add_wrapper(const at::Tensor& A, const at::Tensor& B) {
    at::Tensor C = at::empty_like(A);
    call(A.data_ptr<float>(), B.data_ptr<float>(), C.data_ptr<float>(), 
         A.size(0), A.size(1), c10::cuda::getCurrentCUDAStream());
    return C;
}

TORCH_LIBRARY(tl_demo, m) {
    m.def("elementwise_add(Tensor A, Tensor B) -> Tensor");
}

TORCH_LIBRARY_IMPL(tl_demo, CUDA, m) {
    m.impl("elementwise_add", &elementwise_add_wrapper);
}
```

## 安装

```bash
cd torch_tl_demo
pip install -e .
```

或构建 wheel：

```bash
python setup.py bdist_wheel
pip install dist/torch_tl_demo-0.1.0-*.whl
```

## 使用方式

### 方式 1：通过 PyTorch 算子调用

```python
import torch
import torch_tl_demo

a = torch.randn(1024, 1024, device="cuda")
b = torch.randn(1024, 1024, device="cuda")

result = torch.ops.tl_demo.elementwise_add(a, b)
```

### 方式 2：直接调用打包的源码

```python
import torch
from torch_tl_demo.op_source.elementwise_add import elementwise_add

kernel = elementwise_add(1024, 1024)
a = torch.randn(1024, 1024, device="cuda")
b = torch.randn(1024, 1024, device="cuda")
c = torch.empty(1024, 1024, device="cuda")

kernel(a, b, c)
```

## 测试

```bash
# 测试 PyTorch 算子
python test_torch.py

# 测试打包的源码
python test_source.py
```

## 添加新算子

1. 在 `elementwise_add/` 同级目录创建新的算子目录
2. 编写 TileLang 算子定义
3. 在 `compile_tl_op/` 中添加编译脚本
4. 在 `src/_inner.cpp` 中添加 C++ wrapper 和注册
5. 更新 `setup.py`

## 关键点

| 组件 | 职责 |
|------|------|
| `elementwise_add/elem_add.py` | 算子定义（纯 TileLang） |
| `compile_tl_op/` | 编译工具，生成 .so |
| `src/_inner.cpp` | C++ wrapper + torch.library 注册 |
| `src/torch_tl_demo/op_source/` | 打包的源码，供直接调用 |
