import torch
import torch_tl_demo


def ref_elementwise_add(a, b):
    return a + b


if __name__ == "__main__":
    M, N = 1024, 1024

    torch.manual_seed(0)
    
    if torch.cuda.is_available():
        device = "cuda"
    else:
        print("CUDA not available, skipping test")
        exit(0)

    a = torch.randn((M, N), dtype=torch.float32, device=device)
    b = torch.randn((M, N), dtype=torch.float32, device=device)

    output = torch.ops.tl_demo.elementwise_add(a, b)
    ref_output = ref_elementwise_add(a, b)

    print("Output shape:", output.shape)
    print("Reference shape:", ref_output.shape)

    if torch.allclose(output, ref_output, rtol=1e-5, atol=1e-5):
        print("\033[92mAll check passed!\033[0m")
    else:
        print("\033[91mCheck failed!\033[0m")
        print(f"Max diff: {(output - ref_output).abs().max()}")
