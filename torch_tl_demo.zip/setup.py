import sys
from pathlib import Path
from setuptools import setup, find_packages
from torch.utils.cpp_extension import BuildExtension, CppExtension

HERE = Path(__file__).parent
SRC = HERE / "src"
PACKAGE_PATH = SRC / "torch_tl_demo"
VERSION_FILE = PACKAGE_PATH / "VERSION"

sys.path.append(HERE.as_posix())
from compile_tl_op import elementwise_add
elementwise_add.update_package_files()

setup(
    name="torch_tl_demo",
    version=VERSION_FILE.read_text(encoding="utf-8").strip(),
    description="TileLang PyTorch Demo - A simple example of integrating TileLang operators into PyTorch",
    packages=find_packages(where=SRC),
    package_dir={"": SRC.as_posix()},
    package_data={PACKAGE_PATH.name: ["*.so"]},
    ext_modules=[
        CppExtension(
            "torch_tl_demo._inner",
            [cpp_path.as_posix() for cpp_path in SRC.glob("*.cpp")],
            extra_compile_args=["-std=c++17"],
        ),
    ],
    cmdclass={"build_ext": BuildExtension},
    python_requires=">=3.8",
    install_requires=[
        "torch>=2.0.0",
        "tilelang",
    ],
)
