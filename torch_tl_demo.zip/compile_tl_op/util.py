import tempfile
from pathlib import Path

from tilelang.jit.adapter.libgen import LibraryGenerator


def wrap_libgen(target="cuda"):
    libgen = LibraryGenerator(target)
    libgen.compile_lib = lambda *args, **kwargs: None
    libgen.libpath = str(tempfile.mktemp(suffix=".so"))
    libgen.srcpath = str(tempfile.mktemp(suffix=".cu"))
    return libgen
