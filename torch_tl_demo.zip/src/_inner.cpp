#include <Python.h>
#include <ATen/Operators.h>
#include <torch/all.h>
#include <torch/library.h>

#include <c10/cuda/CUDAStream.h>

extern "C" {
    void call(
        float* A_handle,
        float* B_handle,
        float* C_handle,
        int64_t M,
        int64_t N,
        cudaStream_t stream
    );
}

at::Tensor elementwise_add_wrapper(const at::Tensor& A, const at::Tensor& B) {
    TORCH_CHECK(A.dim() == 2, "tl_demo.elementwise_add: A must be a 2-D tensor");
    TORCH_CHECK(B.dim() == 2, "tl_demo.elementwise_add: B must be a 2-D tensor");
    TORCH_CHECK(A.sizes() == B.sizes(), "tl_demo.elementwise_add: A and B must have the same shape");

    const int64_t M = A.size(0);
    const int64_t N = A.size(1);

    at::Tensor C = at::empty_like(A);

    cudaStream_t stream = c10::cuda::getCurrentCUDAStream();

    call(
        A.data_ptr<float>(),
        B.data_ptr<float>(),
        C.data_ptr<float>(),
        M,
        N,
        stream
    );

    return C;
}

TORCH_LIBRARY(tl_demo, m) {
    m.def("elementwise_add(Tensor A, Tensor B) -> Tensor");
}

TORCH_LIBRARY_IMPL(tl_demo, CUDA, m) {
    m.impl("elementwise_add", &elementwise_add_wrapper);
}

TORCH_LIBRARY_IMPL(tl_demo, Meta, m) {
    m.impl("elementwise_add", &elementwise_add_wrapper);
}

extern "C" {
    PyObject* PyInit__inner(void)
    {
        static struct PyModuleDef module_def = {
            PyModuleDef_HEAD_INIT,
            "_inner",
            NULL,
            -1,
            NULL,
        };
        return PyModule_Create(&module_def);
    }
}
