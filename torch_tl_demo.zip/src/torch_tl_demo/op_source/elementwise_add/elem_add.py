import sys
from pathlib import Path

import tilelang
import tilelang.language as T


HERE = Path(__file__).parent


@tilelang.jit(out_idx=[2], target="cuda")
def elementwise_add(M: int, N: int, block_M: int = 32, block_N: int = 32):
    """
    Elementwise addition: C = A + B
    
    Parameters
    ----------
    M : int
        First dimension
    N : int
        Second dimension
    block_M : int
        Block size for M dimension
    block_N : int
        Block size for N dimension
    
    Returns
    -------
    JITKernel
        Compiled kernel function
    """
    
    @T.prim_func
    def main(
        A: T.Tensor((M, N), "float32"),
        B: T.Tensor((M, N), "float32"),
        C: T.Tensor((M, N), "float32"),
    ):
        with T.Kernel(T.ceildiv(N, block_N) * T.ceildiv(M, block_M)) as (cid,):
            by = cid // T.ceildiv(N, block_N)
            bx = cid % T.ceildiv(N, block_N)
            
            A_shared = T.alloc_shared((block_M, block_N), "float32")
            B_shared = T.alloc_shared((block_M, block_N), "float32")
            C_local = T.alloc_fragment((block_M, block_N), "float32")
            C_shared = T.alloc_shared((block_M, block_N), "float32")
            
            T.copy(A[by * block_M, bx * block_N], A_shared)
            T.copy(B[by * block_M, bx * block_N], B_shared)
            
            for local_y, local_x in T.Parallel(block_M, block_N):
                C_local[local_y, local_x] = A_shared[local_y, local_x] + B_shared[local_y, local_x]
            
            T.copy(C_local, C_shared)
            T.copy(C_shared, C[by * block_M, bx * block_N])
    
    return main
